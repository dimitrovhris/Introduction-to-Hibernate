package softuni.exam.models.entity;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.awt.*;
import java.util.Set;

@Getter
@Setter
@Table(name = "constellations")
@Entity
public class Constellation extends BaseEntity {

    @Column
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @OneToMany(mappedBy = "constellation")
    private Set<Star> stars;
}
